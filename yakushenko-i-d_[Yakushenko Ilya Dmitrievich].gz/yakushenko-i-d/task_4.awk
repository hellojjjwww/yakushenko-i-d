#!/usr/bin/awk -f

BEGIN {
    FS=","
    OFS="\t"
    count=0
}

NR == 1 {
    next
}

{
    for (i = 1; i <= NF; i++) {
        gsub(/^[ \t]+|[ \t]+$/, "", $i)
    }

    if (NF != 4)
        next

    id=$1
    name=$2
    age=$3
    city=$4

    if (id == "" || name == "" || age == "" || city == "")
        next

    if (age !~ /^[0-9]+$/)
        next

    if (city !~ /^[NL]/)
        next

    if (age <= 28)
        next

    if (seen[id]++)
        next

    print NR, city, name
    count++
}

END {
    print "Количество строк:", count
}
