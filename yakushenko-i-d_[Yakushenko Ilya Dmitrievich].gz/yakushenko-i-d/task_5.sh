#!/bin/bash

find . -maxdepth 2 -type f -name "*.txt" -print0 |
xargs -0 file --mime-type |
grep 'text/plain' |
sed -E '
s/:.*$//
h
s#.*/##
s#^([^,]+), ([0-9-]+ [0-9-]+), ([^.]+\.[^.]+)\.txt$#[\2, \3] \1.txt#
x
G
s#^(.*)\n(.*)$#\1\t\2#
' |
xargs -d '\n' -I {} bash -c '
old=$(printf "%s\n" "{}" | cut -f1)
new=$(printf "%s\n" "{}" | cut -f2)

mv "$old" "$(dirname "$old")/$new"
'
