#!/bin/bash
#
# merge_csv.sh
# GPLv3
#

set -euo pipefail

OUTPUT=""
declare -a FILES
TMP_STDIN=""

##
# @brief Краткая справка
usage() {
    echo "Usage: $0 [-o output.csv] [--] file1.csv file2.csv"
}

##
# @brief Полная справка
help() {
cat <<EOH
CSV merge utility

Options:
  -h, --help        Show help
  --usage           Show short usage
  -o FILE           Output file
  -                 Read CSV from stdin
  --                End of options
EOH
}

##
# @brief Очистка временных файлов
cleanup() {
    [[ -n "$TMP_STDIN" && -f "$TMP_STDIN" ]] && rm -f "$TMP_STDIN"
}

trap cleanup EXIT

##
# @brief Проверка MIME-типа файла
# @param $1 Имя файла
check_mime() {
    local file="$1"
    local mime

    mime=$(file --brief --mime-type "$file")

    if [[ "$mime" != "text/plain" && "$mime" != "text/csv" ]]; then
        echo "Invalid mime-type: $file" >&2
        exit 1
    fi
}

##
# @brief Проверка существования файлов
check_files() {
    for f in "${FILES[@]}"; do
        [[ -f "$f" ]] || {
            echo "File not found: $f" >&2
            exit 1
        }

        check_mime "$f"
    done
}

##
# @brief Проверка идентичности заголовков
check_headers() {
    local reference
    reference=$(head -n1 "${FILES[0]}")

    [[ -n "$reference" ]] || {
        echo "Empty header" >&2
        exit 1
    }

    for f in "${FILES[@]}"; do
        local current
        current=$(head -n1 "$f")

        if [[ "$current" != "$reference" ]]; then
            echo "Headers do not match" >&2
            exit 1
        fi
    done
}

##
# @brief Обработка параметров командной строки
parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -h|--help)
                help
                exit 0
                ;;
            --usage)
                usage
                exit 0
                ;;
            -o)
                [[ $# -lt 2 ]] && {
                    echo "Missing output filename" >&2
                    exit 1
                }
                OUTPUT="$2"
                shift 2
                ;;
            -)
                TMP_STDIN=$(mktemp)
                cat > "$TMP_STDIN"
                FILES+=("$TMP_STDIN")
                shift
                ;;
            --)
                shift
                break
                ;;
            *)
                FILES+=("$1")
                shift
                ;;
        esac
    done

    while [[ $# -gt 0 ]]; do
        FILES+=("$1")
        shift
    done
}

##
# @brief Слияние CSV-файлов
merge_csv() {
    local destination="/dev/stdout"

    if [[ -n "$OUTPUT" ]]; then
        destination="$OUTPUT"
    fi

    : > "$destination"

    local sorted
    sorted=$(printf "%s\n" "${FILES[@]}" | sort -V)

    local first=1

    while read -r file_name; do
        if [[ $first -eq 1 ]]; then
            awk '
                NR == 1 { print; next }
                /^[[:space:]]*$/ { next }
                /^[[:space:]]*##/ { next }
                { print }
            ' "$file_name" > "$destination"

            first=0
        else
            awk '
                NR == 1 { next }
                /^[[:space:]]*$/ { next }
                /^[[:space:]]*##/ { next }
                { print }
            ' "$file_name" >> "$destination"
        fi
    done <<< "$sorted"
}

##
# @brief Основная функция
main() {
    parse_args "$@"

    if [[ ${#FILES[@]} -eq 0 ]]; then
        echo "No input files" >&2
        exit 1
    fi

    check_files
    check_headers
    merge_csv
}

main "$@"
