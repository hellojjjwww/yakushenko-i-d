#!/bin/bash

set -e

echo "Running tests..."

cat > file1.csv <<EOT
id,name
1,John
EOT

cat > file2.csv <<EOT
id,name
2,Alice
EOT

bash task_6.sh file1.csv file2.csv > result.csv

grep -q "John" result.csv
grep -q "Alice" result.csv

echo "Merge test passed"

cat > invalid.csv <<EOT
id,username
1,Bob
EOT

if bash task_6.sh file1.csv invalid.csv 2>/dev/null; then
    echo "Header mismatch test failed"
    exit 1
fi

echo "Header mismatch test passed"

bash task_6.sh -o output.csv file1.csv file2.csv
[[ -f output.csv ]]
grep -q "Alice" output.csv

echo "Output option test passed"

echo -e "id,name\n3,Chris" | bash task_6.sh - file1.csv > stdin_result.csv

grep -q "Chris" stdin_result.csv
grep -q "John" stdin_result.csv

echo "STDIN test passed"

cat > comments.csv <<EOT
id,name
## comment

1,John
   
2,Alice
EOT

bash task_6.sh comments.csv > cleaned.csv

if grep -q "##" cleaned.csv; then
    echo "Comment removal test failed"
    exit 1
fi

if grep -q '^$' cleaned.csv; then
    echo "Empty line removal test failed"
    exit 1
fi

echo "Cleanup test passed"

cat > file10.csv <<EOT
id,name
10,Bob
EOT

bash task_6.sh file1.csv file2.csv file10.csv > sorted.csv

grep -q "Bob" sorted.csv

echo "Natural sort test passed"

echo "All tests passed successfully"
