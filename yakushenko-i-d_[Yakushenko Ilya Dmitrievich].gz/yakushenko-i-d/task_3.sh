#!/bin/sed -Ef

# Удаление пустых строк
/^[[:space:]]*$/d

# Удаление пробелов в начале и конце строки
s/^[[:space:]]+//
s/[[:space:]]+$//

# Комментирование PermitRootLogin
/^[[:space:]]*PermitRootLogin[[:space:]]+/ {
    s/^/#/
}

# Обработка Port
/^[[:space:]]*Port[[:space:]]+/ {

    # Проверка hold-space
    x

    /PORT_FOUND/ {
        x
        s/^/#/
        b
    }

    x

    # Замена значения порта
    s/^[[:space:]]*Port[[:space:]]+.*/Port 2222/

    # Сохранение флага
    x
    s/.*/PORT_FOUND/
    x
}
